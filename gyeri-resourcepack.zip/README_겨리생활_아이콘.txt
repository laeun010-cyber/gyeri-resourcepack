겨리생활 리소스팩 추가 아이콘 안내

기존 gyeribbang 아이템 모델/텍스처는 원본 그대로 보존했습니다.
이번 추가 아이콘은 투명 PNG와 1.21.4+ item definition 방식으로 등록했습니다.

Skript 적용 예시(기존 아이템 생성 줄의 모델 ID만 연결):
set {_icon} to paper with model "gyeri:gui_sword" named colored "&6메뉴 이름"

추가 모델 ID:
- gyeri:gui_sword
- gyeri:gui_pickaxe
- gyeri:gui_axe
- gyeri:gui_shovel
- gyeri:gui_hoe
- gyeri:gui_helmet
- gyeri:gui_chestplate
- gyeri:gui_leggings
- gyeri:gui_boots
- gyeri:gui_enchanting_table
- gyeri:gui_anvil
- gyeri:gui_grindstone
- gyeri:gui_ender_chest
- gyeri:gui_chest
- gyeri:gui_potion
- gyeri:gui_golden_apple

참고: 아이콘 모델은 리소스팩에 등록된 상태이며, 각 GUI 슬롯에서 사용하려면 해당 슬롯 아이템 생성문에 위 model ID를 지정해야 합니다.
기본 상자 인벤토리의 창 전체 배경은 리소스팩만으로 GUI별 교체할 수 없으므로, 슬롯 아이콘 방식으로 적용합니다.
